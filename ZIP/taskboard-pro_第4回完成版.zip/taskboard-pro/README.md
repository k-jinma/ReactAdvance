# TaskBoard Pro ― React発展 第4回 完成版

カンバン方式のタスク管理アプリです。**TanStack Query** を使って、タスクの
**一覧（Read）・作成（Create）・更新（Update）・削除（Delete）** をすべて実装した、
第4回の完成版（宿題①②の解答を含む）です。

> 注: カードの **ドラッグ&ドロップ** と **楽観的更新** は次回（第4.5回）で追加します。
> このプロジェクトには含まれていません（状態変更はカード上のセレクトで行います）。

## 技術スタック

- Vite + React + TypeScript
- TanStack Query（サーバー状態管理）
- Supabase（PostgreSQL）
- react-hook-form + Zod（フォーム入力・検証）

## ディレクトリ構成

```
src/
├── components/
│   ├── Board.tsx        ボード本体（useQuery + useMutation）
│   ├── Column.tsx       レーン（ステータスで絞り込み）
│   ├── TaskCard.tsx     カード（ステータス変更セレクト + 削除ボタン）
│   └── TaskForm.tsx     追加フォーム
├── hooks/
│   ├── useTasks.ts            一覧取得（useQuery）
│   ├── useCreateTask.ts       追加（useMutation）
│   ├── useUpdateTaskStatus.ts ステータス更新（useMutation）
│   └── useDeleteTask.ts       削除（useMutation）
├── lib/
│   ├── supabase.ts         Supabase 接続口
│   ├── database.types.ts   DBの型（本来は gen:db で自動生成）
│   ├── mapTask.ts          境界変換（行 <-> Task）
│   └── tasksApi.ts         CRUD の4関数
├── schemas/
│   └── task.ts             型と Zod スキーマ
├── App.tsx / App.css / index.css / main.tsx
```

## セットアップ手順

### 1. 依存パッケージのインストール

```bash
npm install
```

### 2. Supabase の準備

1. Supabase でプロジェクトを作成します。
2. SQL Editor で `db/schema.sql` を実行し、`tasks` テーブル（とサンプルデータ）を作成します。

### 3. 環境変数の設定

`.env.local.example` を `.env.local` にコピーし、自分のSupabaseの値に書き換えます。

```bash
cp .env.local.example .env.local
```

```
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_xxxxxxxx
```

（値は Supabase の Project Settings → API から取得できます）

### 4. 起動

```bash
npm run dev
```

ブラウザで `http://localhost:5173` を開きます。

## 使い方

- 上部のフォームから、タイトル・担当者・優先度を入れて「追加」
- カード下部のセレクトで **ステータスを変更**（レーンが移動）
- カード右上の **×** で削除（確認ダイアログあり）

## メモ

- `database.types.ts` は本来 `npm run gen:db`（`supabase gen types typescript`）で
  自動生成します。`package.json` の `gen:db` スクリプト内の `YOUR_PROJECT_REF` を
  自分のプロジェクト参照IDに置き換えて使ってください。
- 認証（ログイン必須化）は第5回で扱います。現状は誰でもアクセスできます。
