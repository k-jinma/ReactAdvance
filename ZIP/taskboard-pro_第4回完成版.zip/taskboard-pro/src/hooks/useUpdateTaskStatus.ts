import { useMutation, useQueryClient } from "@tanstack/react-query";
import { updateTaskStatus } from "../lib/tasksApi";
import type { TaskStatus } from "../schemas/task";

export function useUpdateTaskStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }: { id: string; status: TaskStatus }) =>
      updateTaskStatus(id, status),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] }),
  });
}
