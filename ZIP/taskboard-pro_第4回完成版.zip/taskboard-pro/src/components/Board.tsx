import type { TaskInput } from "../schemas/task";
import { useTasks } from "../hooks/useTasks";
import { useCreateTask } from "../hooks/useCreateTask";
import { Column } from "./Column";
import { TaskForm } from "./TaskForm";

export function Board() {
  const { data: tasks = [], isPending, isError, error } = useTasks();
  const createTask = useCreateTask();

  const handleAdd = (input: TaskInput) => {
    createTask.mutate(input);
  };

  if (isPending) return <div className="board__loading">読み込み中...</div>;
  if (isError) return <div className="board__error">エラー: {error.message}</div>;

  return (
    <div className="board">
      <div className="board__toolbar">
        <TaskForm onSubmit={handleAdd} />
      </div>
      <div className="board__columns">
        <Column status="todo" title="ToDo" tasks={tasks} />
        <Column status="doing" title="Doing" tasks={tasks} />
        <Column status="review" title="Review" tasks={tasks} />
        <Column status="done" title="Done" tasks={tasks} />
      </div>
    </div>
  );
}
