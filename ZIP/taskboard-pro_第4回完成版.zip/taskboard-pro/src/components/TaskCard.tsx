import type { Task, TaskStatus } from "../schemas/task";
import { useUpdateTaskStatus } from "../hooks/useUpdateTaskStatus";
import { useDeleteTask } from "../hooks/useDeleteTask";

type Props = {
  task: Task;
};

const STATUS_OPTIONS: { value: TaskStatus; label: string }[] = [
  { value: "todo", label: "ToDo" },
  { value: "doing", label: "Doing" },
  { value: "review", label: "Review" },
  { value: "done", label: "Done" },
];

export function TaskCard({ task }: Props) {
  const updateStatus = useUpdateTaskStatus();
  const deleteTask = useDeleteTask();

  return (
    <div className="task-card">
      <div className="task-card__top">
        <div className="task-card__title">{task.title}</div>
        <button
          type="button"
          className="task-card__delete"
          onClick={() => {
            if (confirm(`「${task.title}」を削除しますか?`)) {
              deleteTask.mutate(task.id);
            }
          }}
        >
          ×
        </button>
      </div>
      <div className="task-card__meta">
        <span className={`task-card__priority task-card__priority--${task.priority}`}>
          {task.priority}
        </span>
        <span className="task-card__assignee">{task.assignee}</span>
      </div>
      <select
        className="task-card__status"
        value={task.status}
        onChange={(e) =>
          updateStatus.mutate({ id: task.id, status: e.target.value as TaskStatus })
        }
      >
        {STATUS_OPTIONS.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}
