import { Board } from "./components/Board";
import "./App.css";

function App() {
  return (
    <div className="app">
      <header className="app__header">
        <h1 className="app__title">TaskBoard Pro</h1>
        <p className="app__subtitle">React発展 第4回 完成版 ― 一覧・作成・更新・削除</p>
      </header>
      <main className="app__main">
        <Board />
      </main>
    </div>
  );
}

export default App;
