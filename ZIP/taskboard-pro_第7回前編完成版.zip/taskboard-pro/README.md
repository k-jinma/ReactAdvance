# TaskBoard Pro ― React発展 第7回 前編完成版

カンバン方式のタスク管理アプリです。第6回（RLS）までの状態に、**第7回 前編（ステップ1〜3）**の
内容を足した状態です。カードをクリックするとタスク詳細モーダルが開き、ダミーの添付一覧と
ドロップゾーンが表示されます。ファイルをドロップすると**コンソールにファイル名が出る**ところまでで、
実際のアップロード・Signed URL・削除は **後編（React発展 7.5）** で実装します。

## 前編で追加したもの

- `src/components/TaskDetailModal.tsx` … タスク詳細モーダル（添付はダミー表示）
- `src/components/FileDropzone.tsx` … ドラッグ&ドロップ / クリック選択（`onFiles` で親へ渡す）
- `src/components/Board.tsx` … `selectedTaskId` の state とモーダルの開閉
- `src/components/Column.tsx` / `TaskCard.tsx` … クリック通知（`onOpenTask` / `onOpen`）
- `src/App.css` … 末尾にモーダル / ドロップゾーン / 添付一覧のスタイルを追記
- `db/attachments.sql` … 台帳テーブル `task_attachments` + その RLS + Storage（`storage.objects`）の RLS

## セットアップ

```bash
npm install
cp .env.local.example .env.local   # 自分のSupabaseの値に書き換える
npm run dev
```

Supabase 側では、次の順に準備してください。

1. `db/schema.sql` → `db/policies.sql` を SQL Editor で実行（第5回・第6回まで済んでいれば不要）
2. **Storage → New bucket** で `attachments` という名前のバケットを **Public bucket をオフ**にして作成
3. `db/attachments.sql` を SQL Editor で実行（台帳テーブル + そのRLS + Storage側のRLS）

## 動作の流れ（前編終了時点）

1. ログインしてボードを表示し、カードを**クリック**すると詳細モーダルが開く（8px以上動かすとドラッグ）
2. モーダルにはダミーの添付2件と、点線のドロップゾーンが表示される
3. ドロップゾーンにファイルを落とす（またはクリックして選択）と、ブラウザのコンソールにファイル名の配列が出る

## 補足

- `tsconfig.json` から `references` を外してあります（TypeScript 5.6 以降で `npm run build` が
  TS6310 で止まるため）。詳細は第7回テキスト末尾の補足を参照してください。
- 続きは「React発展(7.5) 添付ファイル後編 ― アップロード・Signed URL・削除」から。
  後編完了時点のコードは `taskboard-pro_第7回完成版.zip` にあります。
