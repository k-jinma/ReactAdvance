-- =====================================================================
-- 第6回:tasks テーブルの Row Level Security
-- Supabase の SQL Editor で実行してください
-- =====================================================================

-- RLS を有効にする(この時点では、ポリシーがないため全操作が拒否される)
alter table tasks enable row level security;

-- SELECT:自分が作った行だけ読み取れる
create policy "select_own_tasks"
  on tasks
  for select
  to authenticated
  using ( created_by = auth.uid() );

-- INSERT:自分のID(created_by)を持つ行だけ追加できる
create policy "insert_own_tasks"
  on tasks
  for insert
  to authenticated
  with check ( created_by = auth.uid() );

-- UPDATE:自分の行だけ更新でき、更新後も自分の行のままであること
create policy "update_own_tasks"
  on tasks
  for update
  to authenticated
  using ( created_by = auth.uid() )
  with check ( created_by = auth.uid() );

-- DELETE:自分の行だけ削除できる
create policy "delete_own_tasks"
  on tasks
  for delete
  to authenticated
  using ( created_by = auth.uid() );
