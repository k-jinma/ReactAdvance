-- =====================================================================
-- 第7回:添付ファイル(Supabase Storage + task_attachments テーブル)
-- Supabase の SQL Editor で実行してください
-- ※ バケット "attachments" は、先にダッシュボードの Storage で
--    「Public bucket をオフ」にして作成しておきます
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. 添付ファイルの台帳テーブル
--    ファイル本体は Storage に置き、ここには「どこに置いたか」を残す
-- ---------------------------------------------------------------------
create table if not exists public.task_attachments (
  id            uuid primary key default gen_random_uuid(),
  task_id       uuid not null references public.tasks (id) on delete cascade,
  file_name     text not null,          -- 表示用の元のファイル名
  storage_path  text not null,          -- Storage 上のキー(<userId>/<taskId>/xxxx.ext)
  mime_type     text not null,          -- image/png, application/pdf など
  size          integer not null,       -- バイト数
  created_by    uuid references auth.users (id) default auth.uid(),
  created_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 2. task_attachments の RLS(第6回と同じ「自分の行だけ」パターン)
-- ---------------------------------------------------------------------
alter table task_attachments enable row level security;

create policy "select_own_attachments"
  on task_attachments
  for select
  to authenticated
  using ( created_by = auth.uid() );

create policy "insert_own_attachments"
  on task_attachments
  for insert
  to authenticated
  with check ( created_by = auth.uid() );

create policy "delete_own_attachments"
  on task_attachments
  for delete
  to authenticated
  using ( created_by = auth.uid() );

-- ---------------------------------------------------------------------
-- 3. Storage 側の RLS(storage.objects テーブルへのポリシー)
--    storage.objects は最初から RLS が有効なので、ポリシーを足すだけ
--    「バケットが attachments で、パスの先頭フォルダが自分のユーザーID」の
--    ファイルだけを読める・置ける・消せる
-- ---------------------------------------------------------------------
create policy "select_own_files"
  on storage.objects
  for select
  to authenticated
  using (
    bucket_id = 'attachments'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "insert_own_files"
  on storage.objects
  for insert
  to authenticated
  with check (
    bucket_id = 'attachments'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "delete_own_files"
  on storage.objects
  for delete
  to authenticated
  using (
    bucket_id = 'attachments'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
