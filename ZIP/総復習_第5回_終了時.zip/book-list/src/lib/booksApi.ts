// src/lib/booksApi.ts(課題1)
import { supabase } from "./supabase";

// 本1冊分のデータの型(books テーブルの1行と同じ形)
export type Book = {
  id: number;
  title: string;
  author: string;
};

// 本の一覧を取ってくる関数
// SQL の select id, title, author from books order by id; と同じ
export async function fetchBooks(): Promise<Book[]> {
  const { data, error } = await supabase
    .from("books")
    .select("id, title, author")
    .order("id");

  if (error) throw error; // 失敗したらエラーを投げる

  return data;
}

// ← 追加:本を1冊追加する関数
// SQL の insert into books (title, author) values ('本の名前', '著者'); と同じ
export async function createBook(newBook: { title: string; author: string }): Promise<void> {
  const { error } = await supabase.from("books").insert(newBook);
  if (error) throw error;
}

// ← 追加:本を1冊削除する関数
// SQL の delete from books where id = 番号; と同じ
export async function deleteBook(id: number): Promise<void> {
  const { error } = await supabase.from("books").delete().eq("id", id);
  if (error) throw error;
}
