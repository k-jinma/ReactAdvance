// src/App.tsx(課題1 ステップD)
import { useState } from "react";
import { fetchBooks, createBook, deleteBook } from "./lib/booksApi"; // ← 変更:deleteBook も読み込む
import type { Book } from "./lib/booksApi";

function App() {
  const [books, setBooks] = useState<Book[]>([]);
  const [title, setTitle] = useState(""); // 入力中の本の名前
  const [author, setAuthor] = useState(""); // 入力中の著者名

  // ボタンが押されたら、本の一覧を取ってきて books に入れる
  const handleLoad = async () => {
    const data = await fetchBooks();
    setBooks(data);
  };

  // 本を DB に追加してから、一覧を取り直す
  const handleAdd = async () => {
    if (!title || !author) return; // どちらかが空なら何もしない
    await createBook({ title, author }); // DB に1件追加する
    await handleLoad(); // 一覧を取り直す
    setTitle("");
    setAuthor("");
  };

  // ← 追加:本を DB から削除してから、一覧を取り直す
  const handleDelete = async (id: number) => {
    await deleteBook(id); // DB から1件削除する
    await handleLoad(); // 一覧を取り直す
  };

  return (
    <div style={{ padding: 24 }}>
      <h1>本の一覧</h1>
      <button onClick={handleLoad}>データを取得</button>

      {/* 本を追加するための入力欄とボタン */}
      <div style={{ marginTop: 16 }}>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="本の名前" />
        <input value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="著者" />
        <button onClick={handleAdd}>+ 追加</button>
      </div>

      <ul>
        {books.map((book) => (
          <li key={book.id}>
            {book.title}({book.author})
            {/* ← 追加:この本を削除するボタン */}
            <button onClick={() => handleDelete(book.id)}>削除</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
