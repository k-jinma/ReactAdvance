// src/lib/booksApi.ts
import { supabase } from "./supabase";

// 本1冊分のデータの型(books テーブルの1行と同じ形)
export type Book = {
  id: number;
  title: string;
  author: string;
};

// 本の一覧を取ってくる関数
// SQL の select id, title, author from books order by id; と同じ
export async function fetchBooks(): Promise<Book[]> {
  const { data, error } = await supabase
    .from("books")
    .select("id, title, author")
    .order("id");

  if (error) throw error; // 失敗したらエラーを投げる

  return data;
}
