// src/App.tsx
import { useState } from "react";
import { fetchBooks } from "./lib/booksApi";
import type { Book } from "./lib/booksApi";

function App() {
  const [books, setBooks] = useState<Book[]>([]);

  // ボタンが押されたら、本の一覧を取ってきて books に入れる
  const handleLoad = async () => {
    const data = await fetchBooks();
    setBooks(data);
  };

  return (
    <div style={{ padding: 24 }}>
      <h1>本の一覧</h1>
      <button onClick={handleLoad}>データを取得</button>
      <ul>
        {books.map((book) => (
          <li key={book.id}>
            {book.title}({book.author})
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
