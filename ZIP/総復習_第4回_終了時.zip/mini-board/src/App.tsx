// src/App.tsx(第4回の完成版)
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { TaskStatus } from "./types/task";
import { Column } from "./components/Column";
import { fetchTasks, createTask, deleteTask } from "./lib/tasksApi";

function App() {
  const [title, setTitle] = useState("");
  const [status, setStatus] = useState<TaskStatus>("todo");

  const { data: tasks = [], isPending, isError, error } = useQuery({
    queryKey: ["tasks"],
    queryFn: fetchTasks,
  });
  const queryClient = useQueryClient();

  const addMutation = useMutation({
    mutationFn: createTask,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteTask,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] }),
  });

  const handleAdd = () => {
    if (!title) return;
    addMutation.mutate({ title, status });
    setTitle("");
  };

  const handleDelete = (id: string) => {
    deleteMutation.mutate(id);
  };

  if (isPending) return <p style={{ padding: 24 }}>読み込み中...</p>;
  if (isError) return <p style={{ padding: 24, color: "crimson" }}>エラー:{error.message}</p>;

  return (
    <div style={{ padding: 24, fontFamily: "sans-serif" }}>
      <h1>mini-board</h1>
      <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="新しいタスク" />
      <select value={status} onChange={(e) => setStatus(e.target.value as TaskStatus)}>
        <option value="todo">ToDo</option>
        <option value="doing">Doing</option>
        <option value="done">Done</option>
      </select>
      <button onClick={handleAdd} disabled={addMutation.isPending}>
        {addMutation.isPending ? "追加中..." : "+ 追加"}
      </button>

      <div style={{ display: "flex", gap: 16, marginTop: 16 }}>
        <Column status="todo" title="ToDo" tasks={tasks} onDelete={handleDelete} />
        <Column status="doing" title="Doing" tasks={tasks} onDelete={handleDelete} />
        <Column status="done" title="Done" tasks={tasks} onDelete={handleDelete} />
      </div>
    </div>
  );
}

export default App;
