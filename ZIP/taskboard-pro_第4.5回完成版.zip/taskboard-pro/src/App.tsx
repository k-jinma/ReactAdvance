import { Board } from "./components/Board";
import "./App.css";

function App() {
  return (
    <div className="app">
      <header className="app__header">
        <h1 className="app__title">TaskBoard Pro</h1>
        <p className="app__subtitle">React発展 第4.5回 完成版 ― ドラッグで状態遷移 + 楽観的更新</p>
      </header>
      <main className="app__main">
        <Board />
      </main>
    </div>
  );
}

export default App;
