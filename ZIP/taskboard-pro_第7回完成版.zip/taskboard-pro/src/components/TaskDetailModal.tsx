import type { Task } from "../schemas/task";
import { useAttachments } from "../hooks/useAttachments";
import { useUploadAttachments } from "../hooks/useUploadAttachments";
import { useDeleteAttachment } from "../hooks/useDeleteAttachment";
import { FileDropzone } from "./FileDropzone";
import { AttachmentItem } from "./AttachmentItem";

type Props = {
  task: Task;
  onClose: () => void;
};

export function TaskDetailModal({ task, onClose }: Props) {
  const { data: attachments = [], isPending, isError, error } = useAttachments(task.id);
  const upload = useUploadAttachments(task.id);
  const remove = useDeleteAttachment(task.id);

  return (
    // 背景(暗幕)をクリックしたら閉じる
    <div className="modal__backdrop" onClick={onClose}>
      {/* 本体のクリックは背景へ伝えない(伝わると閉じてしまう) */}
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal__header">
          <h2 className="modal__title">{task.title}</h2>
          <button type="button" className="modal__close" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="modal__meta">
          <span className={`task-card__priority task-card__priority--${task.priority}`}>
            {task.priority}
          </span>
          <span>担当:{task.assignee}</span>
          <span>状態:{task.status}</span>
        </div>

        <h3 className="modal__section">添付ファイル</h3>

        <FileDropzone
          onFiles={(files) => upload.mutate(files)}
          disabled={upload.isPending}
        />
        {upload.isError && (
          <p className="modal__error">アップロードに失敗しました: {upload.error.message}</p>
        )}

        {isPending && <p className="modal__note">読み込み中...</p>}
        {isError && <p className="modal__error">エラー: {error.message}</p>}
        {!isPending && !isError && attachments.length === 0 && (
          <p className="modal__note">まだ添付はありません</p>
        )}

        <ul className="attachment-list">
          {attachments.map((attachment) => (
            <AttachmentItem
              key={attachment.id}
              attachment={attachment}
              onDelete={() => {
                if (confirm(`「${attachment.fileName}」を削除しますか?`)) {
                  remove.mutate(attachment);
                }
              }}
            />
          ))}
        </ul>
      </div>
    </div>
  );
}
