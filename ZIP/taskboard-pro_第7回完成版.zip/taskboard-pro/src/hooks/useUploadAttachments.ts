import { useMutation, useQueryClient } from "@tanstack/react-query";
import { uploadAttachment } from "../lib/attachmentsApi";
import { useAuth } from "../contexts/AuthContext";

export function useUploadAttachments(taskId: string) {
  const queryClient = useQueryClient();
  const { user } = useAuth();   // 第5回で作った受け取り口。Storage のパスに自分のIDを使う

  return useMutation({
    // 複数ファイルをまとめて受け取り、1件ずつのアップロードを並行して待つ
    mutationFn: (files: File[]) => {
      if (!user) throw new Error("ログインが必要です");
      return Promise.all(files.map((file) => uploadAttachment(taskId, user.id, file)));
    },
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ["attachments", taskId] }),
  });
}
