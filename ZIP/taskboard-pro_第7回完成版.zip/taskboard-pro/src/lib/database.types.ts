// このファイルは本来 `npm run gen:db`(supabase gen types typescript)で自動生成します。
// ここでは tasks テーブルに対応する最小構成を手書きで用意しています。
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type Database = {
  public: {
    Tables: {
      tasks: {
        Row: {
          id: string;
          project_id: string;
          title: string;
          assignee: string;
          priority: string;
          status: string;
          due_date: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          project_id: string;
          title: string;
          assignee: string;
          priority?: string;
          status?: string;
          due_date?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          project_id?: string;
          title?: string;
          assignee?: string;
          priority?: string;
          status?: string;
          due_date?: string | null;
          created_at?: string;
        };
        Relationships: [];
      };
      // 第7回で追加:添付ファイルの台帳(ファイル本体は Storage、ここには「どこに置いたか」を残す)
      task_attachments: {
        Row: {
          id: string;
          task_id: string;
          file_name: string;
          storage_path: string;
          mime_type: string;
          size: number;
          created_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          task_id: string;
          file_name: string;
          storage_path: string;
          mime_type: string;
          size: number;
          created_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          task_id?: string;
          file_name?: string;
          storage_path?: string;
          mime_type?: string;
          size?: number;
          created_by?: string | null;
          created_at?: string;
        };
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
};
