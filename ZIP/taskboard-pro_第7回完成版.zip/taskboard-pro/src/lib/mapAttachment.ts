import type { Database } from "./database.types";
import type { Attachment } from "../schemas/attachment";

type AttachmentRow = Database["public"]["Tables"]["task_attachments"]["Row"];

// 【読み込みの出口】DBの行(スネークケース) + Signed URL → フロントの Attachment(キャメルケース)
export function rowToAttachment(row: AttachmentRow, signedUrl: string): Attachment {
  return {
    id: row.id,
    taskId: row.task_id,
    fileName: row.file_name,
    storagePath: row.storage_path,
    mimeType: row.mime_type,
    size: row.size,
    createdAt: row.created_at,
    signedUrl,
  };
}
