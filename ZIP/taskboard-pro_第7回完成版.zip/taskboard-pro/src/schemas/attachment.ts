// アプリ内で扱う添付ファイル(DBの行 + Storage の閲覧URL を1つにまとめた形・キャメルケース)
export type Attachment = {
  id: string;
  taskId: string;
  fileName: string;     // 表示用の元のファイル名(例: "設計書 v2.pdf")
  storagePath: string;  // Storage 上の置き場所(例: "<userId>/<taskId>/xxxx.pdf")
  mimeType: string;     // "image/png" / "application/pdf" など
  size: number;         // バイト数
  createdAt: string;
  signedUrl: string;    // 有効期限付きの閲覧URL(一覧取得のたびに発行し直す)
};
