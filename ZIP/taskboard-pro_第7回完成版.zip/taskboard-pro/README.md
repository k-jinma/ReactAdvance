# TaskBoard Pro ― React発展 第7回 完成版

カンバン方式のタスク管理アプリです。**TanStack Query** による CRUD、
**ドラッグ&ドロップ + 楽観的更新**（第4.5回）、**Supabase Auth による認証**（第5回）、
**Row Level Security**（第6回）に加えて、**Supabase Storage による添付ファイル**（第7回）まで
実装した状態です。

## 技術スタック

- Vite + React + TypeScript
- TanStack Query（サーバー状態管理）
- Supabase（PostgreSQL + Auth + Storage）
- @dnd-kit/core（ドラッグ&ドロップ）
- React Router（ページの切り替えとログインチェック）
- react-hook-form + Zod（フォーム入力・検証）

## ディレクトリ構成

```
src/
├── components/
│   ├── Board.tsx             ボード本体（useQuery + useMutation + DndContext + 詳細モーダルの開閉）
│   ├── Column.tsx            レーン（useDroppable でドロップ先になる）
│   ├── TaskCard.tsx          カード（useDraggable + 削除ボタン + クリックで詳細を開く）
│   ├── TaskForm.tsx          追加フォーム
│   ├── Header.tsx            メール表示 + ログアウト
│   ├── ProtectedRoute.tsx    ログインチェック
│   ├── TaskDetailModal.tsx   【第7回】タスク詳細モーダル（添付ファイルの一覧・追加・削除）
│   ├── FileDropzone.tsx      【第7回】ドラッグ&ドロップ / クリック選択でファイルを受け取る
│   └── AttachmentItem.tsx    【第7回】添付1件（画像プレビュー / PDFアイコン / 開くリンク / 削除）
├── contexts/
│   └── AuthContext.tsx       ログイン状態の共有 + useAuth
├── pages/
│   └── LoginPage.tsx         ログイン / 新規登録画面
├── hooks/
│   ├── useTasks.ts               一覧取得（useQuery）
│   ├── useCreateTask.ts          追加（useMutation）
│   ├── useUpdateTaskStatus.ts    ステータス更新（楽観的更新つき）
│   ├── useDeleteTask.ts          削除（useMutation）
│   ├── useAttachments.ts         【第7回】添付一覧（useQuery / queryKey にタスクIDを含める）
│   ├── useUploadAttachments.ts   【第7回】複数ファイルのアップロード（useMutation + useAuth）
│   └── useDeleteAttachment.ts    【第7回】添付の削除（useMutation）
├── lib/
│   ├── supabase.ts           Supabase 接続口（DB・認証・Storage すべてに使う）
│   ├── database.types.ts     DBの型（本来は gen:db で自動生成。task_attachments を追記済み）
│   ├── mapTask.ts            境界変換（行 <-> Task）
│   ├── mapAttachment.ts      【第7回】境界変換（行 + Signed URL -> Attachment）
│   ├── tasksApi.ts           tasks の CRUD
│   └── attachmentsApi.ts     【第7回】添付の一覧 / アップロード / 削除（Storage + DB の2段階）
├── schemas/
│   ├── task.ts               型と Zod スキーマ
│   └── attachment.ts         【第7回】Attachment 型
├── App.tsx / App.css / index.css / main.tsx
db/
├── schema.sql        第3回・第5回（tasks テーブルと created_by 列）
├── policies.sql      第6回（tasks の RLS ポリシー）
└── attachments.sql   【第7回】task_attachments テーブル + その RLS + Storage（storage.objects）の RLS
```

## セットアップ

```bash
npm install
cp .env.local.example .env.local   # 自分のSupabaseの値に書き換える
npm run dev
```

Supabase 側では、次の順に準備してください。

1. `db/schema.sql` → `db/policies.sql` を SQL Editor で実行（第5回・第6回まで済んでいれば不要）
2. Authentication → Sign In / Providers で **Email を有効化**、授業用に **Confirm email をオフ**
3. **Storage → New bucket** で `attachments` という名前のバケットを **Public bucket をオフ**にして作成
4. `db/attachments.sql` を SQL Editor で実行（台帳テーブル + そのRLS + Storage側のRLS）

## 動作の流れ

1. ログインしてボードを表示し、カードを**クリック**すると詳細モーダルが開く（8px以上動かすとドラッグ）
2. モーダルのドロップゾーンに画像やPDFをドロップ（またはクリックして選択）すると、
   `Storage(<userId>/<taskId>/<uuid>.<ext>)` にファイル本体を置き、`task_attachments` に台帳の行を追加する
3. 一覧表示のたびに `createSignedUrls` で**有効期限付きの Signed URL**（1時間）を発行し、
   画像はプレビュー、PDF はアイコン + 「開く」リンクとして表示する
4. 添付の × で、Storage のファイルと台帳の行を両方削除する
5. 別のアカウントでログインしても、他人のタスクも添付も見えない（tasks / task_attachments / storage.objects の RLS）

## 補足

- Storage のキーの**先頭フォルダを自分のユーザーID**にし、`storage.objects` のポリシーで
  「先頭フォルダが `auth.uid()` と一致するファイルだけ」を読める・置ける・消せるようにしています。
  Signed URL の発行にも SELECT ポリシーが効くため、他人のファイルの URL は発行すらできません。
- `tsconfig.json` から `references` を外しました（TypeScript 5.6 以降では、`noEmit` の
  `tsconfig.node.json` を参照していると `npm run build`（`tsc -b`）が `TS6310` で止まるため）。
  `vite.config.ts` は Vite 自身が読み込むので、型チェックの対象から外れても動作に影響はありません。
- バケットの設定で「許可する MIME タイプ」や「ファイルサイズ上限」を絞っておくと、
  フロントの `accept` 属性をすり抜けたファイルも Storage 側で弾けます（追加チャレンジ）。
